import java.util.Scanner;
public interface iFine {
    public void PrintFine();
    }
  class SpeedingFines{
      public void PrintFine() {
          Scanner scanner =new Scanner(System.in.toString());

          String name;
          int speed;
          double finepayable;

          System.out.println("enter persons name");
          System.out.println("enter speed");
System.out.println("enter fine payable");
      }
  }