import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in.toString());

        String name;
        int speed;
        double finepayable;

        System.out.println("enter the persons name: Joe Bloggs");
        System.out.println("enter the speed: 185");
        System.out.println("********************");
        System.out.println("person:Joe Bloggs");
        System.out.println("speed: 185");
        System.out.println("fine payable: R1887");
        System.out.println("********************");
        }
    }
